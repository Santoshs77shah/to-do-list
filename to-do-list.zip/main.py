import os


# Function to display the menu
def display_menu():
  print("1. View To-Do List")
  print("2. Add Task")
  print("3. Complete Task")
  print("4. Exit")


# Function to view the current To-Do List
def view_todo_list():
  with open("todo.txt", "r") as file:
    tasks = file.readlines()
    if not tasks:
      print("No tasks in the To-Do List.")
    else:
      for idx, task in enumerate(tasks, start=1):
        print(f"{idx}. {task.strip()}")


# Function to add a new task to the To-Do List
def add_task():
  task = input("Enter the task: ")
  with open("todo.txt", "a") as file:
    file.write(task + "\n")
  print("Task added successfully.")


# Function to mark a task as complete and remove it from the To-Do List
def complete_task():
  view_todo_list()
  try:
    task_index = int(input("Enter the number of the task to complete: "))
    with open("todo.txt", "r") as file:
      tasks = file.readlines()
    with open("todo.txt", "w") as file:
      for idx, task in enumerate(tasks, start=1):
        if idx != task_index:
          file.write(task)
    print("Task completed and removed from the To-Do List.")
  except ValueError:
    print("Invalid input. Please enter a valid task number.")


# Main function
def main():
  while True:
    display_menu()
    choice = input("Enter your choice (1-4): ")
    if choice == "1":
      view_todo_list()
    elif choice == "2":
      add_task()
    elif choice == "3":
      complete_task()
    elif choice == "4":
      print("Exiting the To-Do List application. Goodbye!")
      break
    else:
      print("Invalid choice. Please enter a number between 1 and 4.")


if __name__ == "__main__":
  if not os.path.exists("todo.txt"):
    with open("todo.txt", "w"):
      pass
  main()
